# LeetCode_top_50_SQL
I have successfully completed the top 50 LeetCode SQL questions. My approach to solving these problems has been quite familiar, as I emphasized clarity and simplicity in my solutions. I primarily utilized subqueries to break down complex problems, making the solutions easy to follow and understand for everyone
